<?php

/**
 * validate.php
 *
 * @copyright 1999-2021 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id$
 * @package squirrelmail
 */

echo "Rewrite your code, we now use init.php";
die();
?>