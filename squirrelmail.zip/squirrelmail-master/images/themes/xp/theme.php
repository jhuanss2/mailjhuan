<?php

/**
 * Theme description
 *
 * @copyright 2004-2021 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id$
 * @package squirrelmail
 * @subpackage themes
 */
$icon_themes[] = array('NAME'=>_("XP"),'PATH'=> SM_PATH . 'images/themes/xp/');
