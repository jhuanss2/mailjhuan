<?php

/**
 * index.php
 *
 * Redirects to the index.html file.
 *
 * @copyright 1999-2021 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id$
 * @package squirrelmail
 */

header('Location: index.html');

